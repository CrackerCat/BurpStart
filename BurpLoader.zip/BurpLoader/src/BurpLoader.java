import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

public class BurpLoader {

	public static void main(String[] args) throws IOException {
		File currentDir = new File(System.getProperty("user.dir"));
		File[] files = currentDir.listFiles(new FileFilter() {
			public boolean accept(File pathname) {
				return Pattern.compile("burpsuite", Pattern.CASE_INSENSITIVE).matcher(pathname.getName()).find();
			}
		});

		if (files.length == 1) {
			Runtime.getRuntime().exec("java -Xbootclasspath/p:BurpLoader.jar -jar " + files[0].getAbsolutePath());
		} else {
			JOptionPane.showMessageDialog(null, files.length > 1 ? "当前目录发现多个Burp Pro的jar包" : "当前目录未发现Burp Pro的jar包",
					"Burp Pro包加载异常", JOptionPane.WARNING_MESSAGE);
		}
	}

}
