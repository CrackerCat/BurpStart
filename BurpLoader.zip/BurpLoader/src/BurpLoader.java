import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.*;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

public class BurpLoader {

	public static void main(String[] args) throws IOException {
		String filename = new File(BurpLoader.class.getProtectionDomain().getCodeSource().getLocation().getPath()).getName();

		File f = null;
		String current_dir = null;
		try
		{
			f = new File(BurpLoader.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
			if (f.isDirectory()) {
				current_dir = f.getPath();
			} else {
				current_dir = f.getParentFile().toString();
			}
			System.out.print(current_dir);
		}
		catch (URISyntaxException e)
		{
			e.printStackTrace();
		}
		long newest_time = 0L;
		String newest_file = "not_found";
		try
		{
			DirectoryStream<Path> dirStream = Files.newDirectoryStream(
					Paths.get(current_dir, new String[0]), "burpsuite_*.jar");Throwable localThrowable3 = null;
			try
			{
				for (Path path : dirStream)
				{
					System.out.print(path);
					if (!Files.isDirectory(path, new LinkOption[0]))
					{
						System.out.print(path);
						if (newest_time < path.toFile().lastModified())
						{
							newest_time = path.toFile().lastModified();
							newest_file = path.getFileName().toString();
						}
					}
				}
			}
			catch (Throwable localThrowable5)
			{
				localThrowable3 = localThrowable5;throw localThrowable5;
			}
			finally
			{
				if (dirStream != null) {
					if (localThrowable3 != null) {
						try
						{
							dirStream.close();
						}
						catch (Throwable localThrowable2)
						{
							localThrowable3.addSuppressed(localThrowable2);
						}
					} else {
						dirStream.close();
					}
				}
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		if (newest_file != "not_found") {
			String command = "java -Xbootclasspath/p:" + filename + " -jar " + newest_file;
			System.out.print(command);
			Runtime.getRuntime().exec(command);
		} else {
			JOptionPane.showMessageDialog(null, "当前目录未发现Burp Pro的jar包",
					"Burp Pro包加载异常", JOptionPane.WARNING_MESSAGE);
		}
	}

}
